package com.honq.boost

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

object Ui {
    val BG = 0xFF020813.toInt()
    val RED = 0xFFE60000.toInt()
    val DARK_RED = 0xFF8B0000.toInt()
    val NAVY = 0xFF0A1A3F.toInt()
    val TEXT = 0xFFFF2A2A.toInt()
    val SOFT = 0xFF7F8FB5.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun panelBg(c: Context, radius: Int = 20): GradientDrawable = GradientDrawable().apply {
        setColor(BG)
        cornerRadius = dp(c, radius).toFloat()
        setStroke(dp(c, 2), RED)
    }

    fun label(c: Context, t: String, size: Float = 13f, color: Int = TEXT, bold: Boolean = true): TextView =
        TextView(c).apply {
            text = t
            textSize = size
            setTextColor(color)
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD_ITALIC else Typeface.NORMAL)
        }

    fun title(c: Context, t: String = "HONQ/BOOST", size: Float = 18f): TextView {
        val s = SpannableString(t)
        val i = t.indexOf('/')
        if (i >= 0) s.setSpan(ForegroundColorSpan(RED), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return TextView(c).apply {
            text = s
            textSize = size
            setTextColor(0xFFB8C4E0.toInt())
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        }
    }

    fun button(c: Context, t: String, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
        background = GradientDrawable().apply {
            setColor(DARK_RED)
            cornerRadius = dp(c, 10).toFloat()
            setStroke(dp(c, 1), RED)
        }
        setOnClickListener { onClick() }
    }

    fun toggle(c: Context, t: String, initial: Boolean = false, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 4), 0, dp(c, 4))
        }
        val tv = label(c, t, 12f)
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(c).apply {
            isChecked = initial
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(RED, SOFT))
            trackTintList = ColorStateList(states, intArrayOf(DARK_RED, NAVY))
            setOnCheckedChangeListener { _, b -> onChange(b) }
        }
        row.addView(sw)
        return row
    }

    fun bar(c: Context): ProgressBar =
        ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(RED)
            progressBackgroundTintList = ColorStateList.valueOf(NAVY)
        }

    fun seek(c: Context, max: Int, progress: Int, onChange: (Int, Boolean) -> Unit): SeekBar =
        SeekBar(c).apply {
            this.max = max
            this.progress = progress
            progressTintList = ColorStateList.valueOf(RED)
            thumbTintList = ColorStateList.valueOf(RED)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = onChange(p, fromUser)
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

    fun matchW(heightPx: Int = ViewGroup.LayoutParams.WRAP_CONTENT, topDp: Int = 0, c: Context? = null) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx).apply {
            if (c != null) topMargin = dp(c, topDp)
        }

    fun add(parent: LinearLayout, v: View, topDp: Int = 8) {
        parent.addView(v, matchW(ViewGroup.LayoutParams.WRAP_CONTENT, topDp, parent.context))
    }
}

class GaugeView(c: Context) : View(c) {
    var value = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 6f
        p.style = Paint.Style.FILL
        p.color = 0xFF111111.toInt()
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 6f
        p.color = Ui.RED
        canvas.drawCircle(cx, cy, r, p)
        val ang = Math.toRadians((135 + 270 * value.coerceIn(0f, 1f)).toDouble())
        p.strokeWidth = 9f
        p.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(
            cx, cy,
            (cx + r * 0.8f * cos(ang)).toFloat(),
            (cy + r * 0.8f * sin(ang)).toFloat(),
            p
        )
        p.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, 10f, p)
    }
}
