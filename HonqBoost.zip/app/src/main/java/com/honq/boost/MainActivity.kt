package com.honq.boost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private val sideItems = mutableListOf<TextView>()
    private lateinit var menus: List<Pair<String, (LinearLayout) -> Unit>>

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        menus = listOf(
            "Game Achievements" to { p: LinearLayout -> pageAchievements(p) },
            "Network Settings" to { p: LinearLayout -> pageNetwork(p) },
            "Screen Settings" to { p: LinearLayout -> pageScreen(p) },
            "Anti Mistouch" to { p: LinearLayout -> pageToggles(p, "Anti Mistouch", listOf("Aktifkan anti mistouch", "Mode jangkauan kecil")) },
            "Competitive Key" to { p: LinearLayout -> pageToggles(p, "Competitive Key", listOf("Tombol kompetitif kiri", "Tombol kompetitif kanan")) },
            "Watermark" to { p: LinearLayout -> pageWatermark(p) },
            "Profile" to { p: LinearLayout -> pageProfile(p) },
            "Task Manager" to { p: LinearLayout -> pageTask(p) },
            "Cooling" to { p: LinearLayout -> pageCooling(p) },
            "Permissions" to { p: LinearLayout -> pagePermissions(p) },
            "Help" to { p: LinearLayout -> pageHelp(p) },
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(d(12), d(40), d(12), d(12))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(d(56), d(32)))
        top.addView(
            Ui.title(this, "GAME SPACE CENTER", 16f).apply { setPadding(d(10), 0, 0, 0) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        top.addView(Ui.button(this, "START") { startFloating() })
        root.addView(top)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((i, m) in menus.withIndex()) {
            val tv = Ui.label(this, m.first, 13f, Ui.SOFT).apply {
                setPadding(d(10), d(12), d(8), d(12))
                setOnClickListener { select(i) }
            }
            sideItems.add(tv)
            side.addView(tv)
        }
        body.addView(ScrollView(this).apply { addView(side) }, LinearLayout.LayoutParams(d(120), ViewGroup.LayoutParams.MATCH_PARENT))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14), d(8), d(6), d(8))
        }
        body.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = d(12) })
        setContentView(root)
        select(0)
    }

    private fun select(i: Int) {
        for ((idx, tv) in sideItems.withIndex()) {
            if (idx == i) {
                tv.setTextColor(0xFFFFFFFF.toInt())
                tv.setBackgroundColor(Ui.DARK_RED)
            } else {
                tv.setTextColor(Ui.SOFT)
                tv.setBackgroundColor(0)
            }
        }
        content.removeAllViews()
        menus[i].second(content)
    }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin 'Tampil di atas app lain' dulu", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Floating window aktif. Buka game lo.", Toast.LENGTH_SHORT).show()
    }

    // ---------- halaman ----------
    private fun header(p: LinearLayout, t: String) {
        p.addView(Ui.label(this, t.uppercase(), 16f))
    }

    private fun pageAchievements(p: LinearLayout) {
        header(p, "Game Achievements")
        val hours = SystemClock.elapsedRealtime() / 3600000.0
        Ui.add(p, Ui.label(this, "RAM terpakai: ${Stats.ramUsedMb(this)} / ${Stats.ramTotalMb(this)} MB", 13f, 0xFFFFFFFF.toInt(), false))
        Ui.add(p, Ui.label(this, "Baterai: ${Stats.batteryPct(this)}%", 13f, 0xFFFFFFFF.toInt(), false))
        Ui.add(p, Ui.label(this, "HP menyala: ${"%.1f".format(hours)} jam", 13f, 0xFFFFFFFF.toInt(), false))
    }

    private fun pageNetwork(p: LinearLayout) {
        header(p, "Network Settings")
        Ui.add(p, Ui.label(this, "Optimasi jaringan memakai pengaturan bawaan Android.", 13f, 0xFFFFFFFF.toInt(), false))
        Ui.add(p, Ui.button(this, "Buka pengaturan Wi-Fi") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }, 12)
    }

    @Suppress("DEPRECATION")
    private fun pageScreen(p: LinearLayout) {
        header(p, "Screen Settings")
        val hz = windowManager.defaultDisplay.refreshRate
        Ui.add(p, Ui.label(this, "Refresh rate layar: ${"%.0f".format(hz)} Hz", 13f, 0xFFFFFFFF.toInt(), false))
        Ui.add(p, Ui.button(this, "Buka pengaturan layar") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }, 12)
    }

    private fun pageToggles(p: LinearLayout, t: String, names: List<String>) {
        header(p, t)
        for (n in names) Ui.add(p, Ui.toggle(this, n) { Toast.makeText(this, "$n: ${if (it) "ON" else "OFF"} (uji coba)", Toast.LENGTH_SHORT).show() }, 10)
    }

    private fun pageWatermark(p: LinearLayout) {
        header(p, "Watermark")
        Ui.add(p, Ui.toggle(this, "Watermark game space") { }, 10)
        Ui.add(p, Ui.toggle(this, "Watermark video") { }, 6)
        val et = EditText(this).apply {
            setText("game space")
            setTextColor(0xFFFFFFFF.toInt())
        }
        Ui.add(p, et, 10)
    }

    private fun pageProfile(p: LinearLayout) {
        header(p, "Profile")
        val w = 0xFFFFFFFF.toInt()
        Ui.add(p, Ui.label(this, "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}", 13f, w, false))
        Ui.add(p, Ui.label(this, "Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})", 13f, w, false))
        Ui.add(p, Ui.label(this, "RAM total: ${Stats.ramTotalMb(this)} MB", 13f, w, false))
    }

    private fun pageTask(p: LinearLayout) {
        header(p, "Task Manager")
        val info = Ui.label(this, "RAM terpakai: ${Stats.ramUsedMb(this)} MB (${Stats.ramPercent(this)}%)", 13f, 0xFFFFFFFF.toInt(), false)
        Ui.add(p, info)
        Ui.add(p, Ui.button(this, "Bersihkan RAM") {
            val n = Stats.cleanRam(this)
            Toast.makeText(this, "Mencoba menutup $n app di latar belakang", Toast.LENGTH_SHORT).show()
            info.text = "RAM terpakai: ${Stats.ramUsedMb(this)} MB (${Stats.ramPercent(this)}%)"
        }, 12)
    }

    private fun pageCooling(p: LinearLayout) {
        header(p, "Cooling")
        val t = Ui.label(this, "Suhu baterai: ${"%.1f".format(Stats.tempC(this))}°C", 13f, 0xFFFFFFFF.toInt(), false)
        Ui.add(p, t)
        Ui.add(p, Ui.button(this, "Refresh") { t.text = "Suhu baterai: ${"%.1f".format(Stats.tempC(this))}°C" }, 12)
    }

    private fun pagePermissions(p: LinearLayout) {
        header(p, "Permissions")
        Ui.add(p, Ui.button(this, "Tampil di atas app lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, 12)
        Ui.add(p, Ui.button(this, "Ubah pengaturan sistem (kecerahan)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }, 10)
        Ui.add(p, Ui.button(this, "Notifikasi") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }, 10)
    }

    private fun pageHelp(p: LinearLayout) {
        header(p, "Help")
        Ui.add(p, Ui.label(this,
            "1. Aktifkan izin di menu Permissions.\n2. Tekan START untuk memunculkan floating window.\n3. Aktifkan 'Mode Ekternal' untuk membuka window kedua.\n\nCatatan: Bypass Charging, GPU limit, dan Gyro masih tampilan uji coba.",
            13f, 0xFFFFFFFF.toInt(), false), 10)
    }
}
